#include <stdio.h>
#include "util.h"
#include "table.h"
#include "symbol.h"
#include "absyn.h"
#include "temp.h"
#include "tree.h"
#include "printtree.h"
#include "frame.h"
#include "translate.h"

struct Tr_access_ {
	//Lab5: your code here
};


struct Tr_accessList_ {
	Tr_access head;
	Tr_accessList tail;	
};



struct Tr_level_ {
	//Lab5: your code here
};

struct Tr_exp_ {
	//Lab5: your code here
};


