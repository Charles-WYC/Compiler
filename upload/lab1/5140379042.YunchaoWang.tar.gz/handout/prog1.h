#ifndef PROG1_H
#define PROG1_H
#include "slp.h"
A_stm prog(void);
A_stm prog_prog(void);
A_stm right_prog(void);
A_stm error_prog(void);
#endif
